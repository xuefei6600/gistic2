mkdir -p test
sh run_gistic.sh \
	-seg CNV.segment.txt \
	-mk b38/freec.wes_w10000.markersfile.txt \
	-refgene b38/hg38.refgene.mat \
	-b test \
	-rx 1 -ext xls -fname ALL -ta 0.1 -td 0.1 -js 1 -qvt 0.25 -cap 1.5 -board 0 -maxseg 2000 -conf 0.95 -genegistic 1 -armpeel 0 -smallmem 1
