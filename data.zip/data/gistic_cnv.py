import os,sys,HTSeq
import argparse
from argparse import RawTextHelpFormatter
import numpy as np
import subprocess,math
import re

CancerGenes = '/opt/GISTIC/data/CancerGenes.db'
b37_mat = '/opt/GISTIC/data/b37/hg19.refgene.mat'
b38_mat = '/opt/GISTIC/data/b38/hg38.refgene.mat"'

parser = argparse.ArgumentParser(description='Identification of significantly amplified or deleted regions across a set of samples (GISTIC).',formatter_class=RawTextHelpFormatter)
parser.add_argument('-i', '--cnvlist', help='CNV list, one sample per line, seperated by tab.\n sampleID\tCNVlist', required=True)
parser.add_argument('-m', '--marker', help='Probe maker files for GISTIC', default=None)
parser.add_argument('-o', '--outdir', help='Output dir', required=True)
parser.add_argument('-l', '--samplelist', help='Samplelist', default=None)
parser.add_argument('-g', '--gene-model', help='Gene model bed file, default: refseq', default="refseq")
parser.add_argument('-c', '--chr', type=int, default=0, help="For CNV, chr index number, default: 0")
parser.add_argument('-s', '--start', type=int, default=1, help="For CNV, start index number, default: 1")
parser.add_argument('-e', '--end', type=int, default=2, help="For CNV, end index number, default: 2")
parser.add_argument('-p', '--probe', type=int, default=5, help="For CNV, probe index number; if none, provide -1, default: 5")
parser.add_argument('-n', '--cnv', type=int, default=4, help="For CNV, cnv index number, default: 4")
parser.add_argument('-x', '--rx', default=1, help="Remove X-chromosome from analysis, default: 1, remove X.",choices=['0','1'])
parser.add_argument('-v', '--cnvtype', help="CNV column type, default: cnv", choices=['cnv','ratio','log2ratio'], default='cnv')
parser.add_argument('-d', '--driver-genes', help="Driver genes list ", default=CancerGenes)
parser.add_argument('-tatd', '--ampdel_threshold', help= 'Regions with a copy number loss below this value are considered deletions, default = 0.1', default = 0.1)
parser.add_argument('-armpeel', '--armpeel', type=int, help = 'It is useful when peaks are split by noise or chromothripsis,0 :nofilter; 1 : filter, default = 0', default = 0)
parser.add_argument('-b', '--reference', help='reference', default='b37')
argv = parser.parse_args()


if int(argv.rx) == 1:
    length=23
    chrs = [str(x) for x in range(1,23)]
    del_a=['X','Y','MT','M']
else:
    length=24
    chrs = [str(x) for x in range(1,23)]+['X']
    del_a=['Y','MT','M']


if argv.reference == "b37":
    chromlens={
        '1':249250621,'2':243199373,'3':198022430,
        '4':191154276,'5':180915260,'6':171115067,
        '7':159138663,'8':146364022,'9':141213431,
        '10':135534747,'11':135006516,'12':133851895,
        '13':115169878,'14':107349540,'15':102531392,
        '16':90354753,'17':81195210,'18':78077248,
        '19':59128983,'20':63025520,'21':48129895,
        '22':51304566,"X":155270560,"Y":59373566}
    chrLens="249250621,243199373,198022430,191154276,180915260,171115067,159138663,146364022,141213431,135534747,135006516,133851895,115169878,107349540,102531392,90354753,81195210,78077248,59128983,63025520,48129895,51304566,155270560,59373566"
    refGene=b37_mat
else:
    chromlens={
        '1':248956422,'2':242193529,'3':198295559,
        '4':190214555,'5':181538259,'6':170805979,
        '7':159345973,'8':145138636,'9':138394717,
        '10':133797422,'11':135086622,'12':133275309,
        '13':114364328,'14':107043718,'15':101991189,
        '16':90338345,'17':83257441,'18':80373285,
        '19':58617616,'20':64444167,'21':46709983,
        '22':50818468,"X":156040895,"Y":57227415}
    chrLens="248956422,242193529,198295559,190214555,181538259,170805979,159345973,145138636,138394717,133797422,135086622,133275309,114364328,107043718,101991189,90338345,83257441,80373285,58617616,64444167,46709983,50818468,156040895,57227415"
    refGene=b38_mat

def construct_probes(cnvlist,probelist_file,chr=0,start=1,end=2):
    probelist = []
    out = open(probelist_file,'w')
    for each in cnvlist:
        i = 1
        for line in open(cnvlist[each]):
            if i == 1:
                i += 1
                continue
            array = line.strip().split('\t')
            chrtmp = array[chr].replace('chr','')
            if chrtmp not in chrs:
                continue
            probe1 = (chrtmp, array[start])
            probe2 = (chrtmp, array[end])
            if probe1 not in probelist:
                probelist.append(probe1)
                out.write('%s:%s\t%s\t%s\n' % (chrtmp,array[start],chrtmp,array[start]))
            if probe2 not in probelist:
                probelist.append(probe2)
                out.write('%s:%s\t%s\t%s\n' % (chrtmp,array[end],chrtmp,array[end]))
    out.close()
    assert not os.system('sort -k2,2 -k3,3n %s -o %s' % (probelist_file, probelist_file))

def marker2bed(proberlist_file, probelist_bed):
    assert not os.system('sort -k2,2 -k3,3n %s | awk \'{print $2"\\t"$3"\\t"$3}\' > %s' % (proberlist_file, probelist_bed))

def count_probe(cnv_file, probelist_bed):
    intersect = cnv_file+'.intersect'
    assert not os.system('bedtools intersect -a %s -b %s -c > %s' % (cnv_file, probelist_bed, intersect))
    return intersect
#	pipe = subprocess.Popen(['bedtools','intersect','-a',cnv_file,'-b',probelist_bed,'-c'], stdout=subprocess.PIPE)
#	cnv_probecount = {}
#	for line in iter(pipe.stdout.readline, ''):
#		array = line.strip().split('\t')
#		id = (array[3],array[0],array[1],array[2])
#		cnv_probecount[id] = array[4]
#	return cnv_probecount

def log2ratio(cn, cnvtype='cnv'):
    if cnvtype == 'cnv':
        if cn < 0:
            print('CNV type is illegical!')
            sys.exit(1)
        elif cn == 0:
            return -2.0
        else:
            return math.log(cn,2)-1
    elif cnvtype == 'ratio':
        if cn < 0:
            print('CNV type is illegical!')
            sys.exit(1)
        elif cn == 0:
            return -2.0
        else:
            return math.log(cn,2)
    elif cnvtype == 'log2ratio':
        return cn

def getCN(cnv,cnvtype="cnv"):
    cn = cnv
    if cnvtype == 'ratio':
        cn = cnv*2
    elif cnvtype == 'log2ratio':
        cn = (2 ** cnv)*2
    return int(cn+0.5)

def cnv2segments(cnv_file,seg_file,chr=0,start=1,end=2,probe=5,cnv=4,sample=3,cnvtype='cnv'):
    seg = open(seg_file,'w')
    for line in open(cnv_file):
        array = line.strip().split('\t')
        seg.write('%s\t%s\t%s\t%s\t%s\t%f\n'%(array[sample],array[chr],array[start],array[end],array[probe],log2ratio(float(array[cnv]),cnvtype=cnvtype)))
    seg.close()


outdir = argv.outdir
if not os.path.exists(outdir):
    assert not os.system('mkdir %s'%outdir)

cnvlist = dict([each.split()[0:2] for each in open(argv.cnvlist)])
sampleall = [each.split()[0] for each in open(argv.cnvlist)]
samples = sampleall

samplelist = []
if argv.samplelist:
    if ',' in argv.samplelist:
        samplelist = argv.samplelist.split(',')
    else:
        samplelist = [each.split()[0] for each in open(argv.samplelist).read().strip('\n').split('\n')]
    samples = [each for each in samplelist if each in sampleall]


## CNV file; cat many to one
cnv_all_file = os.path.join(outdir,'CNV.bed')
cnv_all = open(os.path.join(outdir,'CNV.bed'),'w')
cnv_heatmap = open(os.path.join(outdir,'CNV.heatmap.dat'),'w')
cnv_heatmap.write('sample\tchr\tstart\tend\tcn\n')

for each in samples:
    i = 1
    for line in open(cnvlist[each]):
        if i == 1:
            i += 1
            continue
        array = line.strip().split('\t')
        chrtmp = array[argv.chr].replace('chr','')
        if chrtmp not in chrs:
            continue
        if (argv.probe == -1) or (not argv.marker):
            cnv_all.write('%s\t%s\t%s\t%s\t%s\n' % (chrtmp, array[argv.start], array[argv.end], each, array[argv.cnv]))
        else:
            cnv_all.write('%s\t%s\t%s\t%s\t%s\t%s\n' % (chrtmp, array[argv.start], array[argv.end], each, array[argv.cnv], array[argv.probe]))
        cnv_heatmap.write('%s\t%s\t%s\t%s\t%d\n' % (each, chrtmp, array[argv.start], array[argv.end], getCN(float(array[argv.cnv]))))
cnv_all.close()
cnv_heatmap.close()

### prepare CNV segmentation file, with 6 column
##	Sample	chr	start	end	probecount	log2Ratio
probe_file = argv.marker
if not argv.marker:
    probe_file = os.path.join(outdir,'markerfiles.txt')
    construct_probes(cnvlist,probe_file,chr=argv.chr,start=argv.start,end=argv.end)

if (not argv.marker) or (argv.probe == -1):
    marker2bed(probe_file, probe_file+'.bed')
    intersect_file = count_probe(cnv_all_file, probe_file+'.bed')
    assert not os.system('rm -f %s' % cnv_all_file)
    cnv_all_file = intersect_file

segfile = os.path.join(outdir,'CNV.segment.txt')
cnv2segments(cnv_all_file, segfile, chr=0, start=1, end=2, probe=5, cnv=4, sample=3, cnvtype=argv.cnvtype)

## hierarchical clustering on CNV
print('hierarchical clustering on CNV')
ga=HTSeq.GenomicArray(chromlens,stranded=False,typecode='i')



def make_ploidy(ga,file,sample,rx):
    outfile=open(os.path.join(outdir,file),'w')
    outfile.write('chr\tstart\tend\t%s\n' %sample)
    for each_chr in chrs:
        for each_pos in range(0,chromlens[each_chr],100000):
            end=min(each_pos+100000,chromlens[each_chr])
            iv=HTSeq.GenomicInterval(each_chr,each_pos,end,".")
            array=list(ga[iv])
            ploidy=round(sum(array)/len(array),4)
            outfile.write(str(each_chr)+'\t'+str(each_pos)+'\t'+str(end)+'\t'+str(ploidy)+'\n')
    outfile.close()

result_array=[]
attr=0
for each in open(argv.cnvlist):
    sample,cnv_file=each.strip().split('\t')
    attr+=1
    for each in chromlens:
        iv=HTSeq.GenomicInterval(each,0,chromlens[each],'.')
        ga[iv]=2
    for each in open(cnv_file):
        array=each.strip().split('\t')
        array[0]=array[0].replace('chr','')
        if array[0] not in chromlens:
            continue
        iv=HTSeq.GenomicInterval(array[argv.chr],int(array[argv.start]),int(array[argv.end]),'.')
        ga[iv]=int(array[argv.cnv])
    result_array.append('result_%d.txt' %(attr))
    make_ploidy(ga,'result_%d.txt' %(attr),sample,argv.rx)

array_cmd=[]
for num in range(1,len(result_array)):
    array_cmd.append('$%s' %((num+1)*4))
cmd='paste %s|awk -F "\\t" -v OFS="\\t" \'{print $1,$2,$3,$4,%s}\'>%s' \
    %(os.path.join(outdir,'result_*'),','.join(array_cmd),os.path.join(outdir,'merge_cnv.txt'))
assert not os.system(cmd)
assert not os.system('rm -rf %s' %os.path.join(outdir,'result_*'))

Rscript='''
setwd('%s')
data<-read.table("merge_cnv.txt",head=T,sep="\\t")
dat<-data[,4:length(data)]
dat<-data.matrix(dat)
d<-dist(t(dat))
h<-hclust(d)
h$labels[h$order]
png("cluster_cnv.png",width=min(nrow(dat)*5+200,3000),height=600,res=72*2,type='cairo-png')
plot(h,hang=-1,xlab="",ylab="",sub="")
dev.off()

pdf("cluster_cnv.pdf", width=min(nrow(dat)*5+2,20), height=4, family="GB1")
plot(h,hang=-1,xlab="",ylab="",sub="")
dev.off()

''' %(outdir)
open(os.path.join(outdir,'Rscript.R'),'w').write(Rscript)

sample_string=subprocess.Popen('Rscript %s' %os.path.join(outdir,'Rscript.R'),shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout.read()
sample_array=re.findall(r'"(.*?)"',sample_string)
rsample=str(tuple(sample_array))
print(rsample)
## GISTIC command
print('GISTIC')
gistic_cmd = '/opt/GISTIC/run_gistic.sh \
    -seg %s -mk %s -refgene %s -b %s -rx %s -ext xls -fname ALL\
    -ta %s -td %s -js 1 -qvt 0.25 -cap 1.5 -board 0  -maxseg 2000\
    -conf 0.95 -genegistic 1 -armpeel %s \
    -smallmem 1' % \
    (segfile, probe_file, refGene, outdir, argv.rx , argv.ampdel_threshold, argv.ampdel_threshold, argv.armpeel)
assert not os.system(gistic_cmd)

assert not os.system('awk \'NR>1{if($2=="23"){print $1"\\tX\\t"$3"\\t"$6"\\n"$1"\\tX\\t"$4"\\t"$6}else{print $1"\\t"$2"\\t"$3"\\t"$6"\\n"$1"\\t"$2"\\t"$4"\\t"$6}}\' %s > %s' % \
    (os.path.join(outdir,'ALL.scores.xls.gistic'), os.path.join(outdir,'scores.gistic.txt')))

#rsample = '","'.join(samples)
rscript = '''
setwd("%s")
leng<-%d
ploidy <- 2
### chromosome length, centromere position
chrLen<-c(%s)
names(chrLen)<-c(1:22,'X','Y')
cumChrLen<-c(0,cumsum(chrLen))[-length(chrLen)-1]
names(cumChrLen)<-c(1:22,'X','Y')
chrpos <- cumChrLen[1:leng-1]+chrLen[1:leng-1]/2

dat<-read.table('scores.gistic.txt',sep="\\t")
colnames(dat) <- c('Type','Chromosome','Pos','Gscore')
dat$Gscore[dat$Gscore<0.1] <- 0
amp <- subset(dat, Type=="Amp")
amp$x <- cumChrLen[as.character(amp$Chromosome)] + amp$Pos
del <- subset(dat, Type=="Del")
del$x <- cumChrLen[as.character(del$Chromosome)] + del$Pos
amp_max = max(amp$Gscore)*1.2
del_max = max(del$Gscore)*1.2

png('CNV_gistic.curve.png',type="cairo-png",width=1400*2,height=500*2,res=72*2)
par(mfrow=c(2,1),mar=c(2,4,2,3))
#plot(amp$x,amp$Gscore,bty='n',xaxt='n',yaxt='n',xlab='',ylab='',type='l',lwd=3,col='#EF502C',ylim=c(0,max(1.5,amp_max)))
plot(amp$x,amp$Gscore,bty='n',xaxt='n',xlab='',ylab='G-score',type='l',lwd=3,col='#EF502C',ylim=c(0,max(1.5,amp_max)))
segments(0,0,cumChrLen[leng],0,lwd=2)
axis(side=3,at=cumChrLen[1:leng],labels=rep('',leng),lwd=3)
text(chrpos,max(1.5,amp_max),names(cumChrLen)[1:leng-1],pos = 3,xpd=T,cex=1.5)
#text(-chrLen[1]/2,-0.5,'AMP',xpd=T,cex=1)

#par(mar=c(5,3,1,3))
#plot(del$x,del$Gscore,bty='n',xaxt='n',yaxt='n',xlab='',ylab='',type='l',lwd=3,col='#3060AD',ylim=c(0,max(del_max,1.5)))
plot(del$x,del$Gscore,bty='n',xaxt='n',xlab='',ylab='G-score',type='l',lwd=3,col='#3060AD',ylim=c(0,max(del_max,1.5)))
segments(0,0,cumChrLen[leng],0,lwd=2)
axis(side=1,at=cumChrLen[1:leng],labels=rep('',leng),lwd=3)
text(chrpos,-0.05,names(cumChrLen)[1:leng-1],pos = 1,xpd=T,cex=1.5)
#text(-chrLen[1]/2,-0.5,'DEL',xpd=T,cex=1)
dev.off()

pdf('CNV_gistic.curve.pdf', width=20, height=5, family="GB1")
par(mfrow=c(2,1),mar=c(2,4,2,3))
plot(amp$x,amp$Gscore,bty='n',xaxt='n',yaxt='n',xlab='',ylab='',type='l',lwd=3,col='#EF502C',ylim=c(0,max(1.5,amp_max)))
segments(0,0,cumChrLen[leng],0,lwd=2)
axis(side=3,at=cumChrLen[1:leng],labels=rep('',leng),lwd=3)
text(chrpos,max(1.5,amp_max),names(cumChrLen)[1:leng-1],pos = 3,xpd=T,cex=1.5)
#text(-chrLen[1]/2,0,'AMP',xpd=T,cex=2)

#par(mar=c(5,3,1,3))
plot(del$x,del$Gscore,bty='n',xaxt='n',yaxt='n',xlab='',ylab='',type='l',lwd=3,col='#3060AD',ylim=c(0,max(del_max,1.5)))
segments(0,0,cumChrLen[leng],0,lwd=2)
axis(side=1,at=cumChrLen[1:leng],labels=rep('',leng),lwd=3)
text(chrpos,-0.05,names(cumChrLen)[1:leng-1],pos = 1,xpd=T,cex=1.5)
#text(-chrLen[1]/2,0,'DEL',xpd=T,cex=2)
dev.off()

cnv <- read.table("CNV.heatmap.dat",sep="\\t",head=T)
samples <- c%s
N <- length(samples)
cols<-c("#FF4040","#FF6767","#FF9999","#FFA2A2","#FFFFFF","#B8B8FF","#3B3BFF")
names(cols)<-c(6,5,4,3,2,1,0)

png("CNV.heatmap.png",width=1400,height=200+13*N,res=72*2,type="cairo-png")
par(mar=c(2,1,2,3))
plot(c(cumChrLen[leng],cumChrLen[leng]),c(0,N),col="white",xlim=c(0,cumChrLen[leng]),xaxt="n",yaxt="n",xlab="",ylab="",bty="n")
for( i in 1:N){
        p<-data.frame(chr=dat$chr,end=dat$end,cn=dat$cn)
        p<-subset(cnv, sample == samples[i])
        p$cn[p$cn>6] <- 6
        p$x<-p$end+cumChrLen[as.character(p$chr)]
        p$col<-cols[as.character(p$cn)]
        for( j in nrow(p):1){
                rect(0,N-i,p$x[j],N-i+1,col=p$col[j],border=NA)
        }
        text(cumChrLen[leng],N-i+0.5,labels=samples[i],pos=4,xpd=T,cex=0.5)
}
segments(0,N*1.05,cumChrLen[leng],N*1.05,lwd=1.5,xpd=T)
for( t in cumChrLen[1:leng] ){
        segments(t,N*1.05,t,N*1.1,xpd=T,lwd=1.5)
}
labels=names(chrpos)
text(chrpos,rep(N*1.05,length(chrpos)),labels=labels,pos=3,cex=0.8,xpd=T)
segments(0,0,cumChrLen[leng]+2000000,0,xpd=T)
segments(0,N,cumChrLen[leng]+2000000,N,xpd=T)
segments(-2000000,0,-2000000,N,xpd=T)
segments(cumChrLen[leng]+2000000,0,cumChrLen[leng]+2000000,N,xpd=T)
dev.off()

pdf('CNV.heatmap.pdf', width=20, height=2+1*N, family="GB1")
par(mar=c(2,1,2,3))
plot(c(cumChrLen[leng],cumChrLen[leng]),c(0,N),col="white",xlim=c(0,cumChrLen[leng]),xaxt="n",yaxt="n",xlab="",ylab="",bty="n")
for( i in 1:N){
        p<-data.frame(chr=dat$chr,end=dat$end,cn=dat$cn)
        p<-subset(cnv, sample == samples[i])
        p$cn[p$cn>6] <- 6
        p$x<-p$end+cumChrLen[as.character(p$chr)]
        p$col<-cols[as.character(p$cn)]
        for( j in nrow(p):1){
                rect(0,N-i,p$x[j],N-i+1,col=p$col[j],border=NA)
        }
        text(cumChrLen[leng],N-i+0.5,labels=samples[i],pos=4,xpd=T,cex=1.5)
}
segments(0,N*1.05,cumChrLen[leng],N*1.05,lwd=1.5,xpd=T)
for( t in cumChrLen[1:leng] ){
        segments(t,N*1.05,t,N*1.1,xpd=T,lwd=1.5)
}
labels=names(chrpos)
text(chrpos,rep(N*1.05,length(chrpos)),labels=labels,pos=3,cex=1.0,xpd=T)
segments(0,0,cumChrLen[leng]+2000000,0,xpd=T)
segments(0,N,cumChrLen[leng]+2000000,N,xpd=T)
segments(-2000000,0,-2000000,N,xpd=T)
segments(cumChrLen[leng]+2000000,0,cumChrLen[leng]+2000000,N,xpd=T)
dev.off()

'''%(outdir, length, chrLens, rsample)
open(os.path.join(outdir,'plot.R'),'w').write(rscript)
assert not os.system('Rscript %s' % (os.path.join(outdir,'plot.R')))

assert not os.system('cut -f1,2,3,7 %s|sed "s/ after removing segments shared with higher peaks//">%s' %(os.path.join(outdir,'ALL.all_lesions.conf_95.xls.txt'),os.path.join(outdir,'CNV.significant_regions.xls')))
driver_genes = [each.split()[0] for each in open(argv.driver_genes).read().strip().split('\n')]

## Result format
print('Result format')
def run_lession(lesion_file):
    d_region2pqcn={}
    sample=[]
    for each in open(lesion_file):
        each=each.strip()
        array=each.split('\t')
        if each.startswith('Unique'):
            sample=array[9:]
            continue
        if not array[0].endswith('values'):
            #print each
            continue
        band=array[1].strip()
        W_peak=array[2].split('(')[0]
        p_value=array[5]
        q_value=array[6]
        attr=[float(i) for i in array[9:]]
        cn=np.array(attr)+2
        d_region2pqcn[(band,W_peak)]=[p_value,q_value,cn]
    return d_region2pqcn,sample

def run_gene(file):
    array=[]
    rank_region=[]
    d_region2gene={}
    for each in open(file):
        each=each.strip('\n')
        attr=each.split('\t')
        array.append(attr)
    aT=np.array(array).T
    for attr in aT[1:]:
        band= attr[0]
        W_peak=attr[3]
        gene_a=[i for i in attr[4:] if i != '']
        d_region2gene[(band,W_peak)]=gene_a
        rank_region.append((band,W_peak))
    return d_region2gene,rank_region

def run2genefile(d_region2pqcn,d_region2gene,sample,outfile,rank_region):
    out=open(outfile,'w')
    out.write('Cytoband'+'\t'+'Wide Peak Boundaries'+'\t'+'P_value'+'\t'+'Q_value'+'\t'+'\t'.join(sample)+'\t'+'Percent'+'\t'+'Genes\tDriver Genes'+'\n')
    for each in rank_region:
        if each not in d_region2pqcn:
            continue
        cn=d_region2pqcn[each][-1]
        attr=[round(i,1) for i in cn]
        nor_cn=[i for i in attr if i !=2]
        percent='%.f%%' %(float(len(nor_cn*100))/len(cn))
        cn=[str(j) for j in attr]
        out.write(each[0]+'\t'+each[1]+'\t'+d_region2pqcn[each][0]+'\t'+d_region2pqcn[each][1]+'\t'+'\t'.join(cn)+'\t'+percent+'\t'+\
			','.join(d_region2gene[each])+'\t'+','.join([x for x in d_region2gene[each] if x in driver_genes])+'\n')


d_region2pqcn,sample=run_lession('%s' %(os.path.join(outdir,'ALL.all_lesions.conf_95.xls.txt')))
d_region2gene,rank_region=run_gene('%s' %(os.path.join(outdir,'ALL.amp_genes.conf_95.xls.txt')))
run2genefile(d_region2pqcn,d_region2gene,sample,'%s' %(os.path.join(outdir,'Amplification_CNVs.genes.xls')),rank_region)
d_region2gene,rank_region=run_gene('%s' %(os.path.join(outdir,'ALL.del_genes.conf_95.xls.txt')))
run2genefile(d_region2pqcn,d_region2gene,sample,'%s' %(os.path.join(outdir,'Deletion_CNVs.genes.xls')),rank_region)

