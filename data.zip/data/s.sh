/miniconda2/bin/python gistic_cnv.py -i /Downloads/test/AdvanceAnalysis/00.prepare/somatic_cnv.list -m b38/freec.wes_w10000.markersfile.txt -o GIstic -b b38
